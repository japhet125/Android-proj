package com.example.myfirstudemy;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.google.android.material.snackbar.Snackbar;


public class MainActivity extends AppCompatActivity {


Button Ok;
TextView result;

ImageView image;
ToggleButton toggleButton;


Spinner spinner;
LinearLayout layout;

ArrayAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Ok = findViewById(R.id.buttonOk);
        result = findViewById(R.id.textViewResult);
        image = findViewById(R.id.imageExample);
        layout = findViewById(R.id.linear);
    spinner = findViewById(R.id.spinnerCountry);
    adapter = ArrayAdapter.createFromResource(this,R.array.countries, android.R.layout.simple_spinner_dropdown_item);
    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
               String country= parent.getItemAtPosition(position).toString();
               result.setText(country);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });



       Ok.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               showDialogMessage();
               image.setImageResource(R.drawable.b);
               Toast.makeText(getApplicationContext(),"This is a toast message",Toast.LENGTH_SHORT).show();
               Snackbar.make(layout,"This is a snackbar message",Snackbar.LENGTH_INDEFINITE).setAction("Close", new View.OnClickListener() {
                   @Override
                   public void onClick(View v) {

                   }
               }).show();

           }
       });

    }

    private void showDialogMessage() {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);
        alertDialog.setTitle("Delete").setMessage("Do you want to delete the text?").setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();

            }
        }).setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                result.setText("");

            }
        }).show();
        alertDialog.create()
;    }

}